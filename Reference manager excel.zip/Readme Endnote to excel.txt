1. Import the Endnote style into Endnote by opening the Style. Endnote should open now
2. Click 'Tools' -> 'Output styles' and select the new style 'Endnote-to-Excel'
3. Select the references you want to copy, and press control + K (or right click and press 'Copy formatted reference')
4. Now paste in your excel file (control + V), the references should be there in the desired format.

Copied and adapted by Joris Osinga from S-Mac (https://www.youtube.com/watch?v=Y40Wy1guAiQ)
j.osinga@erasmusmc.nl